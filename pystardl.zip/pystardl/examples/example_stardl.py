"""STARDL on simulated data: estimation, tests, long run, multipliers, plots."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pystardl import (STARDL, linearity_test, select_lags, compare_transitions,
                      simulate_stardl)

df = simulate_stardl(n=300, seed=1)          # replace with your own DataFrame

# 1. Is there any smooth-transition non-linearity, and in which variable?
lin = linearity_test(df, "y", "x", candidates=["time", "D.x"], delays=(1, 2))
print(lin)

# 2. Lag orders and transition shape
p, q, table = select_lags(df, "y", "x", max_p=3, max_q=2, criterion="bic")
print("selected (p, q) =", (p, q))
ranking, _ = compare_transitions(df, "y", "x", p=p, q=q)
print(ranking)

# 3. Estimation
res = STARDL(df, "y", "x", p=p, q=q, transition_var="time", transition="logistic").fit()
print(res)

# 4. Cointegration bounds test (simulated critical values), diagnostics
print(res.bounds_test(n_sim=300))
print(res.diagnostics())

# 5. Long run by regime, regime path, multipliers
print(res.long_run(g=(0, 0.5, 1)))
print(res.dynamic_multipliers("x", horizon=15).round(3))

# 6. Figures
res.plot_transition().savefig("stardl_transition.png", dpi=150)
res.plot_regime_path().savefig("stardl_regime_path.png", dpi=150)
res.plot_long_run().savefig("stardl_long_run.png", dpi=150)
res.plot_multipliers("x").savefig("stardl_multipliers.png", dpi=150)
res.plot_cusum().savefig("stardl_cusum.png", dpi=150)
plt.close("all")
