"""STNARDL: asymmetric long-run effects that also change smoothly over time."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pystardl import STNARDL, simulate_stnardl

df = simulate_stnardl(n=400, seed=2)          # replace with your own DataFrame

res = STNARDL(df, "y", "x", asym_vars=["x"], p=1, q=1,
              transition_var="time", transition="logistic", cov_type="HAC").fit()
print(res)

# symmetry tests in each regime (and jointly)
print(res.asymmetry_tests().round(4))

# regime-dependent asymmetric multipliers: plus, minus and asym = plus - minus
print(res.dynamic_multipliers("x", horizon=20, g=(0, 1)).round(3))
res.plot_multipliers("x").savefig("stnardl_multipliers.png", dpi=150)
res.plot_transition().savefig("stnardl_transition.png", dpi=150)
res.plot_long_run().savefig("stnardl_long_run.png", dpi=150)
print(res.bounds_test(n_sim=300))
plt.close("all")
