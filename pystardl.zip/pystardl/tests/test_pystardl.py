import matplotlib
matplotlib.use("Agg")
import numpy as np
import pytest

from pystardl import (STARDL, STNARDL, linearity_test, partial_sums, select_lags,
                      simulate_stardl, simulate_stnardl, transition_function)


@pytest.fixture(scope="module")
def res_ar():
    return STARDL(simulate_stardl(300, seed=1), "y", "x").fit()


@pytest.fixture(scope="module")
def res_nar():
    return STNARDL(simulate_stnardl(400, seed=2), "y", "x").fit()


def test_transition_bounds():
    s = np.linspace(-3, 3, 50)
    for kind in ("logistic", "exponential", "logistic2"):
        G = transition_function(s, 4.0, [0.0, 1.0] if kind == "logistic2" else [0.0], kind)
        assert np.all((G >= 0) & (G <= 1))


def test_partial_sums_identity():
    x = np.cumsum(np.random.RandomState(0).randn(50))
    pos, neg = partial_sums(x)
    assert np.allclose(pos + neg, x - x[0])


def test_stardl_recovers_dgp(res_ar):
    assert abs(res_ar.c[0] - 0.5) < 0.08
    lr = res_ar.long_run()["coef"].values
    assert abs(lr[0] - 0.5) < 0.3 and abs(lr[1] - 1.5) < 0.4
    assert res_ar.coefficients["L.y"] < 0


def test_stnardl_asymmetry_detected(res_nar):
    t = res_nar.asymmetry_tests()
    row = t.xs("long-run symmetry", level="hypothesis").xs("both", level="regime")
    assert row["p_chi2"].iloc[0] < 0.01


def test_covariance_types():
    df = simulate_stardl(200, seed=3)
    se = [STARDL(df, "y", "x", cov_type=c).fit().se_beta.mean() for c in ("nonrobust", "HC1", "HAC")]
    assert all(np.isfinite(se))


def test_multipliers_converge_to_long_run(res_nar):
    m = res_nar.dynamic_multipliers("x", horizon=200)
    assert abs(m[("G=1.00", "plus")].iloc[-1] - m[("G=1.00", "lr_plus")].iloc[-1]) < 1e-3


def test_linearity_test_rejects():
    df = simulate_stardl(300, seed=1)
    lin = linearity_test(df, "y", "x", candidates=["time"])
    assert lin.table["p_linear"].iloc[0] < 0.01


def test_bounds_and_diagnostics(res_ar):
    b = res_ar.bounds_test(n_sim=60)
    assert b.F > 0
    d = res_ar.diagnostics()
    assert "Jarque-Bera" in d.index
    assert len(res_ar.cusum()) > 10


def test_lag_selection():
    p, q, tab = select_lags(simulate_stardl(200, seed=4), "y", "x", max_p=2, max_q=1)
    assert 1 <= p <= 2 and 0 <= q <= 1


def test_nonlinear_subsets():
    df = simulate_stardl(200, seed=5)
    r = STARDL(df, "y", "x", nonlinear="lr").fit()
    assert all(n.startswith("G*") for n in r.names_nl)
    r = STARDL(df, "y", "x", nonlinear=["x"]).fit()
    assert "G*L.x" in r.names


def test_bad_inputs():
    df = simulate_stardl(100, seed=6)
    with pytest.raises(ValueError):
        STARDL(df, "y", "x", transition="bogus")
    with pytest.raises(KeyError):
        STARDL(df, "y", "nope")
