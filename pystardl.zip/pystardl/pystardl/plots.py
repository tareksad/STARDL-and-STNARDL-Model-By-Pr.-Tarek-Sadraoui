"""Matplotlib figures for STARDL / STNARDL results."""
import numpy as np


def _plt():
    import matplotlib
    import matplotlib.pyplot as plt
    return plt


def plot_transition(res, ax=None, show=False):
    """Estimated transition function over the range of s, with the density of s."""
    from .transition import transition_function
    plt = _plt()
    if ax is None:
        fig, ax = plt.subplots(figsize=(7, 4))
    else:
        fig = ax.figure
    grid = np.linspace(res.zs.min(), res.zs.max(), 300)
    G = transition_function(grid, res.gamma_std, res.c_std, res.transition_kind)
    x = res.s_mean + res.s_sd * grid
    ax.plot(x, G, lw=2, color="tab:blue", label="G(s)")
    ax.plot(res.s, np.zeros_like(res.s) - 0.03, "|", color="grey", alpha=0.5)
    for c in res.c:
        ax.axvline(c, ls="--", color="tab:red", lw=1)
    ax.set_ylim(-0.08, 1.05)
    ax.set_xlabel("transition variable: %s" % res.model.transition_var)
    ax.set_ylabel("G")
    ax.set_title("%s transition function (gamma=%.3g)" % (res.transition_kind, res.gamma))
    ax.grid(alpha=0.3)
    if show:
        plt.show()
    return fig


def plot_regime_path(res, ax=None, show=False):
    """G_t over the sample: which regime the economy is in at each date."""
    plt = _plt()
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 3.5))
    else:
        fig = ax.figure
    x = np.arange(len(res.G)) if not hasattr(res.index, "to_numpy") else res.index
    ax.plot(x, res.G, color="tab:blue", lw=1.8)
    ax.fill_between(x, 0, res.G, alpha=0.15)
    ax.set_ylim(0, 1.02)
    ax.set_ylabel("G_t")
    ax.set_title("Regime path")
    ax.grid(alpha=0.3)
    if show:
        plt.show()
    return fig


def plot_long_run(res, show=False):
    """Time-varying long-run coefficients -theta(G_t)/rho(G_t)."""
    plt = _plt()
    lr = res.long_run_path()
    fig, ax = plt.subplots(figsize=(8, 4))
    for c in lr.columns:
        ax.plot(lr.index, lr[c], lw=1.8, label=c)
    ax.legend()
    ax.grid(alpha=0.3)
    ax.set_title("Long-run coefficients along the transition")
    if show:
        plt.show()
    return fig


def plot_multipliers(res, variable, horizon=20, g=(0.0, 1.0), show=False):
    """Cumulative dynamic multipliers by regime (asymmetric variables show m+, m-, asym)."""
    plt = _plt()
    mult = res.dynamic_multipliers(variable, horizon, g)
    regimes = list(dict.fromkeys(mult.columns.get_level_values(0)))
    fig, axes = plt.subplots(1, len(regimes), figsize=(5.5 * len(regimes), 4), squeeze=False)
    for ax, reg in zip(axes[0], regimes):
        sub = mult[reg]
        for col in sub.columns:
            if col.startswith("lr"):
                ax.plot(sub.index, sub[col], ls=":", lw=1, color="grey")
            elif col == "asym":
                ax.plot(sub.index, sub[col], color="k", lw=1.6, ls="--", label="asymmetry")
            else:
                ax.plot(sub.index, sub[col], lw=2, label=col)
        ax.axhline(0, color="k", lw=0.5)
        ax.set_title("%s  (%s)" % (variable, reg))
        ax.set_xlabel("horizon")
        ax.grid(alpha=0.3)
        ax.legend()
    fig.tight_layout()
    if show:
        plt.show()
    return fig


def plot_cusum(res, show=False):
    plt = _plt()
    cs = res.cusum()
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
    x = np.arange(len(cs))
    axes[0].plot(x, cs["cusum"], color="tab:blue")
    axes[0].plot(x, cs["cusum_upper"], "r--", lw=1)
    axes[0].plot(x, cs["cusum_lower"], "r--", lw=1)
    axes[0].set_title("CUSUM (5%)")
    axes[1].plot(x, cs["cusumsq"], color="tab:blue")
    axes[1].plot(x, cs["cusumsq_mean"], color="grey", lw=1)
    axes[1].plot(x, cs["cusumsq_upper"], "r--", lw=1)
    axes[1].plot(x, cs["cusumsq_lower"], "r--", lw=1)
    axes[1].set_title("CUSUM of squares (approx. 5%)")
    for a in axes:
        a.grid(alpha=0.3)
    fig.tight_layout()
    if show:
        plt.show()
    return fig


def plot_fit(res, show=False):
    plt = _plt()
    fig, axes = plt.subplots(2, 1, figsize=(8, 5.5), sharex=True)
    axes[0].plot(res.index, res.dy, label="actual", lw=1.2)
    axes[0].plot(res.index, res.fitted, label="fitted", lw=1.2)
    axes[0].legend()
    axes[0].set_title("D.%s: actual vs fitted" % res.depvar)
    axes[1].plot(res.index, res.residuals, color="tab:red", lw=1)
    axes[1].axhline(0, color="k", lw=0.5)
    axes[1].set_title("Residuals")
    for a in axes:
        a.grid(alpha=0.3)
    fig.tight_layout()
    if show:
        plt.show()
    return fig
