"""Regime-dependent cumulative dynamic multipliers."""
import numpy as np
import pandas as pd


def _path(eff, dep, comp, q, p, horizon):
    """Response of y to a unit shock in the level of ``comp`` at t=0."""
    H = horizon
    rho = eff["L." + dep]
    theta = eff.get("L." + comp, 0.0)
    phi = [eff.get("D.%s_l%d" % (dep, i), 0.0) for i in range(1, p)]
    pi = [eff.get("D.%s_l%d" % (comp, i), 0.0) for i in range(q)]
    y = np.zeros(H + 1)
    dy = np.zeros(H + 1)
    lvl = np.ones(H + 1)          # level of the component: 1 from t=0 on
    d = np.zeros(H + 1)
    d[0] = 1.0                    # its first difference
    for t in range(H + 1):
        ylag = y[t - 1] if t > 0 else 0.0
        xlag = lvl[t - 1] if t > 0 else 0.0
        v = rho * ylag + theta * xlag
        for i, ph in enumerate(phi, start=1):
            if t - i >= 0:
                v += ph * dy[t - i]
        for i, pp in enumerate(pi):
            if t - i >= 0:
                v += pp * d[t - i]
        dy[t] = v
        y[t] = ylag + v
    return y


def dynamic_multipliers(res, variable, horizon=20, g=(0.0, 1.0)):
    """Cumulative dynamic multipliers m_h of y to a unit change in a regressor.

    For asymmetric variables the frame has ``plus`` (response to a unit change
    in x+), ``minus`` (response to a unit change in x-) and ``asym`` =
    plus - minus, which is zero under symmetry.  For symmetric variables only
    ``response`` is returned.  ``long_run`` is the limit -theta/rho.
    Columns are MultiIndexed by regime ``G=g``.
    """
    if variable not in res.indepvars:
        raise ValueError("variable must be one of %s" % res.indepvars)
    dep, p = res.depvar, res.model.p
    q = res.model.q_map[variable]
    out = {}
    for gv in np.atleast_1d(g):
        eff = res.effective_coefs(float(gv))
        lab = "G=%.2f" % gv
        rho = eff["L." + dep]
        if variable in res.asym_vars:
            pos, neg = res.level_cols[variable]
            mp = _path(eff, dep, pos, q, p, horizon)
            mn = _path(eff, dep, neg, q, p, horizon)
            out[(lab, "plus")] = mp
            out[(lab, "minus")] = mn
            out[(lab, "asym")] = mp - mn
            out[(lab, "lr_plus")] = np.full(horizon + 1, -eff["L." + pos] / rho)
            out[(lab, "lr_minus")] = np.full(horizon + 1, -eff["L." + neg] / rho)
        else:
            out[(lab, "response")] = _path(eff, dep, variable, q, p, horizon)
            out[(lab, "long_run")] = np.full(horizon + 1, -eff["L." + variable] / rho)
    df = pd.DataFrame(out, index=pd.Index(range(horizon + 1), name="horizon"))
    df.columns = pd.MultiIndex.from_tuples(df.columns)
    return df
