"""Result container for STARDL / STNARDL estimates."""
import numpy as np
import pandas as pd
from scipy import stats
from tabulate import tabulate

from .transition import N_LOCATIONS, transition_function
from .utils import numerical_jacobian, stars


class STResult(object):
    def __init__(self, model, design, idx_nl, beta, cov, gamma_s, c_s,
                 s_mean, s_sd, G, resid, sigma2):
        self.model = model
        self.model_name = model.model_name
        self.depvar, self.indepvars = model.depvar, model.indepvars
        self.asym_vars, self.sym_vars = model.asym_vars, model.sym_vars
        self.transition_kind = model.transition
        self.cov_type = model.cov_type
        self.names_lin = list(design["names"])
        self.idx_nl = list(idx_nl)
        self.names_nl = ["G*" + self.names_lin[i] for i in idx_nl]
        self.names = self.names_lin + self.names_nl
        self.m, self.m1 = len(self.names_lin), len(self.names_nl)
        self.nb = self.m + self.m1
        self.level_cols = design["level_cols"]
        self.beta = np.asarray(beta)
        self.index = design["index"]
        self.dy, self.Z = design["dy"], design["Z"]
        self.W = self.Z[:, self.idx_nl]
        self.G = np.asarray(G)
        self.residuals = np.asarray(resid)
        self.fitted = self.dy - self.residuals
        self.n = len(self.dy)
        self.nloc = N_LOCATIONS[self.transition_kind]
        self.K = self.nb + 1 + self.nloc
        self.df_resid = self.n - self.K
        self.sigma2 = sigma2
        self.cov_full = np.asarray(cov)
        self.cov_beta = self.cov_full[: self.nb, : self.nb]
        self.se_beta = np.sqrt(np.clip(np.diag(self.cov_beta), 0, None))
        # transition parameters on the original scale of s
        self.s_mean, self.s_sd = s_mean, s_sd
        self.s = design["s"]
        self.gamma_std, self.c_std = gamma_s, np.asarray(c_s)
        self.gamma = gamma_s / s_sd
        self.c = s_mean + s_sd * self.c_std
        se_std = np.sqrt(np.clip(np.diag(self.cov_full), 0, None))
        self.gamma_se = se_std[self.nb] / s_sd
        self.c_se = se_std[self.nb + 1:] * s_sd
        self.zs = (self.s - s_mean) / s_sd
        # fit statistics
        self.ssr = float(self.residuals @ self.residuals)
        tss = float(((self.dy - self.dy.mean()) ** 2).sum())
        self.r2 = 1 - self.ssr / tss
        self.adj_r2 = 1 - (1 - self.r2) * (self.n - 1) / self.df_resid
        self.loglik = -0.5 * self.n * (np.log(2 * np.pi) + np.log(self.ssr / self.n) + 1)
        self.aic = -2 * self.loglik + 2 * self.K
        self.bic = -2 * self.loglik + self.K * np.log(self.n)
        self.hqic = -2 * self.loglik + 2 * self.K * np.log(np.log(self.n))
        self.X = np.hstack([self.Z, self.W * self.G[:, None]])

    # ----------------------------------------------------------- coefficients
    @property
    def coefficients(self):
        return dict(zip(self.names, self.beta))

    @property
    def std_errors(self):
        return dict(zip(self.names, self.se_beta))

    @property
    def transition_params(self):
        out = {"gamma": self.gamma}
        if self.nloc == 1:
            out["c"] = float(self.c[0])
        else:
            out["c1"], out["c2"] = float(self.c[0]), float(self.c[1])
        return out

    def coef_table(self):
        names = list(self.names)
        est = list(self.beta)
        se = list(self.se_beta)
        names.append("gamma")
        est.append(self.gamma)
        se.append(self.gamma_se)
        cn = ["c"] if self.nloc == 1 else ["c1", "c2"]
        names += cn
        est += list(self.c)
        se += list(self.c_se)
        est, se = np.array(est), np.array(se)
        with np.errstate(divide="ignore", invalid="ignore"):
            t = est / se
        p = 2 * stats.t.sf(np.abs(t), self.df_resid)
        crit = stats.t.ppf(0.975, self.df_resid)
        return pd.DataFrame({"coef": est, "std_err": se, "t": t, "p_value": p,
                             "ci_low": est - crit * se, "ci_high": est + crit * se},
                            index=names)

    to_dataframe = coef_table

    # -------------------------------------------------------------- long run
    def _E(self, g):
        """Matrix mapping beta to regime-g effective coefficients (m x nb)."""
        E = np.zeros((self.m, self.nb))
        E[:, : self.m] = np.eye(self.m)
        for j, i in enumerate(self.idx_nl):
            E[i, self.m + j] = g
        return E

    def effective_coefs(self, g):
        """Coefficients of the model at transition value ``g`` (0 <= g <= 1)."""
        return dict(zip(self.names_lin, self._E(g) @ self.beta))

    def _lr_cols(self):
        dep = "L." + self.depvar
        return [nm for nm in self.names_lin if nm.startswith("L.") and nm != dep]

    def long_run(self, g=(0.0, 1.0)):
        """Long-run coefficients -theta/rho in the regimes G = g (delta-method SE)."""
        rows = []
        r_i = self.names_lin.index("L." + self.depvar)
        for gv in np.atleast_1d(g):
            E = self._E(float(gv))
            for nm in self._lr_cols():
                j = self.names_lin.index(nm)

                def f(b, E=E, j=j):
                    eff = E @ b
                    return np.array([-eff[j] / eff[r_i]])

                est = f(self.beta)[0]
                Jb = numerical_jacobian(f, self.beta)
                se = float(np.sqrt(max((Jb @ self.cov_beta @ Jb.T)[0, 0], 0)))
                t = est / se if se > 0 else np.nan
                rows.append(dict(regime="G=%.2f" % gv, variable="LR_" + nm[2:], coef=est,
                                 std_err=se, t=t, p_value=2 * stats.t.sf(abs(t), self.df_resid)))
        return pd.DataFrame(rows).set_index(["regime", "variable"])

    def long_run_path(self):
        """Time path of the long-run coefficients, evaluated at the observed G_t."""
        r_i = self.names_lin.index("L." + self.depvar)
        out = {}
        for nm in self._lr_cols():
            j = self.names_lin.index(nm)
            vals = []
            for gt in self.G:
                eff = self._E(gt) @ self.beta
                vals.append(-eff[j] / eff[r_i])
            out["LR_" + nm[2:]] = vals
        return pd.DataFrame(out, index=self.index)

    def speed_of_adjustment(self, g=(0.0, 1.0)):
        r_i = self.names_lin.index("L." + self.depvar)
        return {"G=%.2f" % gv: float((self._E(gv) @ self.beta)[r_i]) for gv in np.atleast_1d(g)}

    # ------------------------------------------------------------ Wald tests
    def wald_test(self, R, r=None):
        """Wald test of R beta = r on the coefficient vector (see ``names``)."""
        R = np.atleast_2d(np.asarray(R, dtype=float))
        r = np.zeros(R.shape[0]) if r is None else np.atleast_1d(np.asarray(r, float))
        diff = R @ self.beta - r
        M = R @ self.cov_beta @ R.T
        q = int(np.linalg.matrix_rank(R))
        W = float(diff @ np.linalg.pinv(M) @ diff)
        return dict(wald=W, df=q, p_chi2=float(stats.chi2.sf(W, q)), F=W / q,
                    p_F=float(stats.f.sf(W / q, q, self.df_resid)))

    def test_coefficients(self, restrictions):
        """Test linear restrictions given as ``{name: weight}`` (all = 0)."""
        R = np.zeros((1, self.nb))
        for nm, w in restrictions.items():
            R[0, self.names.index(nm)] = w
        return self.wald_test(R)

    def test_nonlinear_terms(self):
        """Naive Wald test that all G* coefficients are zero.

        NB: gamma and c are not identified under H0, so the usual chi-square
        distribution does not apply (Davies, 1977).  Use ``linearity_test``
        for a valid test; this is only a descriptive diagnostic.
        """
        R = np.zeros((self.m1, self.nb))
        R[np.arange(self.m1), self.m + np.arange(self.m1)] = 1
        return self.wald_test(R)

    def asymmetry_tests(self, regimes=(0.0, 1.0)):
        """Long-run and short-run symmetry Wald tests (STNARDL only)."""
        rows = []
        for v in self.asym_vars:
            pos, neg = self.level_cols[v]
            for gv in regimes:
                E = self._E(float(gv))
                ip, ineg = self.names_lin.index("L." + pos), self.names_lin.index("L." + neg)
                res = self.wald_test((E[ip] - E[ineg])[None, :])
                rows.append(dict(variable=v, hypothesis="long-run symmetry", regime="G=%.2f" % gv, **res))
                sp = [i for i, nm in enumerate(self.names_lin) if nm.startswith("D.%s_l" % pos)]
                sn = [i for i, nm in enumerate(self.names_lin) if nm.startswith("D.%s_l" % neg)]
                if sp and sn:
                    R = E[sp].sum(axis=0) - E[sn].sum(axis=0)
                    res = self.wald_test(R[None, :])
                    rows.append(dict(variable=v, hypothesis="additive short-run symmetry",
                                     regime="G=%.2f" % gv, **res))
            if len(regimes) == 2:
                E0, E1 = self._E(float(regimes[0])), self._E(float(regimes[1]))
                ip, ineg = self.names_lin.index("L." + pos), self.names_lin.index("L." + neg)
                R = np.vstack([E0[ip] - E0[ineg], E1[ip] - E1[ineg]])
                res = self.wald_test(R)
                rows.append(dict(variable=v, hypothesis="long-run symmetry", regime="both", **res))
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(rows).set_index(["variable", "hypothesis", "regime"])

    # ---------------------------------------------------------- other tools
    def dynamic_multipliers(self, variable, horizon=20, g=(0.0, 1.0)):
        from .multipliers import dynamic_multipliers
        return dynamic_multipliers(self, variable, horizon, g)

    def bounds_test(self, **kwargs):
        from .tests import bounds_test
        return bounds_test(self, **kwargs)

    def diagnostics(self, lags=(1, 4)):
        from .tests import diagnostics
        return diagnostics(self, lags=lags)

    def cusum(self):
        from .tests import cusum
        return cusum(self)

    def plot_transition(self, **kw):
        from . import plots
        return plots.plot_transition(self, **kw)

    def plot_regime_path(self, **kw):
        from . import plots
        return plots.plot_regime_path(self, **kw)

    def plot_long_run(self, **kw):
        from . import plots
        return plots.plot_long_run(self, **kw)

    def plot_multipliers(self, variable, **kw):
        from . import plots
        return plots.plot_multipliers(self, variable, **kw)

    def plot_cusum(self, **kw):
        from . import plots
        return plots.plot_cusum(self, **kw)

    def plot_fit(self, **kw):
        from . import plots
        return plots.plot_fit(self, **kw)

    # -------------------------------------------------------------- display
    def header(self):
        w = 78
        lines = [
            "%s Estimation Results" % self.model_name,
            "Dependent variable (ECM): D.%s" % self.depvar,
            "Transition: %s | variable: %s (delay %d)" % (
                self.transition_kind, self.model.transition_var, self.model.delay),
            "N = %d | parameters = %d | df resid = %d" % (self.n, self.K, self.df_resid),
            "R2 = %.4f | adj R2 = %.4f | sigma = %.5f" % (self.r2, self.adj_r2, np.sqrt(self.sigma2)),
            "AIC = %.3f | BIC = %.3f | HQIC = %.3f | cov = %s" % (self.aic, self.bic, self.hqic, self.cov_type),
        ]
        top = "\u2554" + "\u2550" * (w - 2) + "\u2557"
        bot = "\u255a" + "\u2550" * (w - 2) + "\u255d"
        body = ["\u2551 " + l.ljust(w - 4) + " \u2551" for l in lines]
        return "\n".join([top] + body + [bot])

    def summary_table(self, digits=4):
        t = self.coef_table()
        rows = []
        for nm, r in t.iterrows():
            rows.append([nm, r["coef"], r["std_err"], r["t"], r["p_value"] ,
                         stars(r["p_value"]), "[%.*f, %.*f]" % (digits, r["ci_low"], digits, r["ci_high"])])
        return tabulate(rows, headers=["Variable", "Coef.", "Std.Err.", "t", "P>|t|", "", "95% CI"],
                        tablefmt="fancy_grid", floatfmt=".%df" % digits)

    def summary(self, long_run=True):
        parts = [self.header(), self.summary_table()]
        if long_run:
            lr = self.long_run().reset_index()
            parts.append("Long-run coefficients (delta method)")
            parts.append(tabulate(lr.values.tolist(), headers=list(lr.columns),
                                  tablefmt="fancy_grid", floatfmt=".4f"))
            sa = self.speed_of_adjustment()
            parts.append("Speed of adjustment: " + ", ".join("%s: %.4f" % kv for kv in sa.items()))
        return "\n".join(parts)

    def __str__(self):
        return self.summary()

    def __repr__(self):
        return "<%s result: n=%d, gamma=%.4g, c=%s>" % (self.model_name, self.n, self.gamma,
                                                       np.round(self.c, 4).tolist())

    def to_latex(self, digits=4):
        return self.coef_table().round(digits).to_latex()

    def to_html(self, digits=4):
        return self.coef_table().round(digits).to_html()
