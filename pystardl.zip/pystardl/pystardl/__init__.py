"""pystardl: Smooth Transition ARDL (STARDL) and Smooth Transition NARDL (STNARDL).

Author: Pr. Tarek Sadraoui <Tarek.sadraoui@gmail.com>
"""
from .stardl import STARDL
from .stnardl import STNARDL
from .results import STResult
from .tests import linearity_test, bounds_test, diagnostics, cusum
from .lag_selection import select_lags, compare_transitions
from .multipliers import dynamic_multipliers
from .transition import transition_function
from .datasets import simulate_stardl, simulate_stnardl
from .utils import partial_sums

__version__ = "0.1.0"
__author__ = "Tarek Sadraoui"
__all__ = ["STARDL", "STNARDL", "STResult", "linearity_test", "bounds_test", "diagnostics",
           "cusum", "select_lags", "compare_transitions", "dynamic_multipliers", "transition_function",
           "simulate_stardl", "simulate_stnardl", "partial_sums"]
