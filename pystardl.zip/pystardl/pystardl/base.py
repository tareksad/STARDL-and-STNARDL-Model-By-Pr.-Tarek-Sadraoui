"""Common estimation engine for STARDL and STNARDL.

Model (error-correction form, regime-dependent coefficients)::

    dy_t = Z_t' b0 + G(s_t; gamma, c) * W_t' b1 + e_t

``Z_t`` holds the deterministic terms, the lagged levels (long run) and the
lagged differences (short run).  ``W_t`` is the subset of ``Z_t`` that is
allowed to change smoothly between regimes.  For fixed (gamma, c) the model is
linear, so the transition parameters are found by a grid search followed by a
Nelder-Mead refinement of the concentrated sum of squares (variable
projection).  Standard errors come from the full non-linear least squares
Jacobian.
"""
import re
from collections import OrderedDict

import numpy as np
import pandas as pd
from scipy import optimize

from .transition import (KINDS, N_LOCATIONS, decode, encode, make_grid,
                         transition_function)
from .utils import as_list, newey_west_meat, numerical_jacobian, partial_sums


def _ols_ssr(dy, Z, W, G):
    X = np.hstack([Z, W * G[:, None]])
    beta = np.linalg.lstsq(X, dy, rcond=None)[0]
    r = dy - X @ beta
    return float(r @ r), beta


class STBase(object):
    model_name = "ST"

    def __init__(self, data, depvar, indepvars, asym_vars=None, p=1, q=1,
                 transition_var="time", delay=0, transition="logistic",
                 nonlinear="all", constant=True, trend=False, time_col=None,
                 cov_type="nonrobust", hac_lags=None, n_gamma=9, n_c=15,
                 gamma_max=300.0):
        if transition not in KINDS:
            raise ValueError("transition must be one of %s" % (KINDS,))
        if cov_type not in ("nonrobust", "HC1", "HAC"):
            raise ValueError("cov_type must be 'nonrobust', 'HC1' or 'HAC'")
        self.depvar = depvar
        self.indepvars = as_list(indepvars)
        self.asym_vars = [v for v in as_list(asym_vars)]
        for v in self.asym_vars:
            if v not in self.indepvars:
                raise ValueError("asym_vars must be a subset of indepvars")
        self.sym_vars = [v for v in self.indepvars if v not in self.asym_vars]
        self.p = int(p)
        if self.p < 1:
            raise ValueError("p must be >= 1")
        if isinstance(q, dict):
            self.q_map = {v: int(q.get(v, 1)) for v in self.indepvars}
        else:
            self.q_map = {v: int(q) for v in self.indepvars}
        self.q = q
        self.transition_var = transition_var
        self.delay = int(delay)
        self.transition = transition
        self.nonlinear = nonlinear
        self.constant = constant
        self.trend = trend
        self.cov_type = cov_type
        self.hac_lags = hac_lags
        self.n_gamma, self.n_c, self.gamma_max = n_gamma, n_c, float(gamma_max)

        df = data.copy()
        if time_col is not None:
            df = df.sort_values(time_col).set_index(time_col)
        need = [depvar] + self.indepvars
        tv = transition_var
        if isinstance(tv, str) and tv != "time":
            need.append(tv[2:] if tv.startswith("D.") and tv[2:] in df.columns else tv)
        need = list(OrderedDict.fromkeys(need))
        missing = [c for c in need if c not in df.columns]
        if missing:
            raise KeyError("columns not found in data: %s" % missing)
        self.data = df[need].dropna()
        if len(self.data) < 20:
            raise ValueError("too few observations after dropping missing values")

    # ------------------------------------------------------------------ design
    def _components(self, df):
        comps = OrderedDict()
        comps[self.depvar] = df[self.depvar].astype(float)
        level_cols = OrderedDict()
        for v in self.indepvars:
            x = df[v].astype(float)
            if v in self.asym_vars:
                pos, neg = partial_sums(x)
                comps[v + "_pos"], comps[v + "_neg"] = pos, neg
                level_cols[v] = [v + "_pos", v + "_neg"]
            else:
                comps[v] = x
                level_cols[v] = [v]
        return comps, level_cols

    def _trans_series(self, df):
        tv, n = self.transition_var, len(df)
        if isinstance(tv, str) and tv == "time":
            return pd.Series(np.arange(1, n + 1) / float(n), index=df.index)
        if isinstance(tv, str):
            if tv.startswith("D.") and tv[2:] in df.columns:
                s = df[tv[2:]].astype(float).diff()
            else:
                s = df[tv].astype(float)
        else:
            s = pd.Series(np.asarray(tv, dtype=float), index=df.index)
        return s.shift(self.delay)

    def _design(self, df, s_override=None):
        comps, level_cols = self._components(df)
        y = comps[self.depvar]
        dy = y.diff()
        cols = OrderedDict()
        if self.constant:
            cols["const"] = pd.Series(1.0, index=df.index)
        if self.trend:
            cols["trend"] = pd.Series(np.arange(1, len(df) + 1, dtype=float), index=df.index)
        cols["L." + self.depvar] = y.shift(1)
        for v in self.indepvars:
            for c in level_cols[v]:
                cols["L." + c] = comps[c].shift(1)
        for i in range(1, self.p):
            cols["D.%s_l%d" % (self.depvar, i)] = dy.shift(i)
        for v in self.indepvars:
            for c in level_cols[v]:
                dc = comps[c].diff()
                for i in range(self.q_map[v]):
                    cols["D.%s_l%d" % (c, i)] = dc.shift(i)
        names = list(cols.keys())
        X = pd.DataFrame(cols)
        X["__dy"] = dy
        X["__s"] = self._trans_series(df) if s_override is None else \
            pd.Series(np.asarray(s_override, float), index=df.index)
        X = X.dropna()
        return dict(dy=X["__dy"].values, Z=X[names].values, s=X["__s"].values,
                    names=names, index=X.index, level_cols=level_cols, comps=comps)

    def _nl_index(self, names):
        nl = self.nonlinear
        if isinstance(nl, str) and nl == "all":
            idx = [i for i, nm in enumerate(names) if nm != "trend"]
        elif isinstance(nl, str) and nl == "lr":
            idx = [i for i, nm in enumerate(names) if nm == "const" or nm.startswith("L.")]
        elif isinstance(nl, str) and nl == "sr":
            idx = [i for i, nm in enumerate(names) if nm.startswith("D.")]
        else:
            idx = []
            for tok in as_list(nl):
                if tok in names:
                    idx.append(names.index(tok))
                    continue
                comps = [tok]
                if tok in self.asym_vars:
                    comps = [tok + "_pos", tok + "_neg"]
                found = [i for i, nm in enumerate(names)
                         if any(nm == "L." + c or re.match(r"^D\.%s_l\d+$" % re.escape(c), nm)
                                for c in comps)]
                if not found:
                    raise ValueError("unknown nonlinear term %r; columns are %s" % (tok, names))
                idx.extend(found)
            idx = sorted(set(idx))
        if not idx:
            raise ValueError("no coefficient is allowed to change with the transition")
        return idx

    # --------------------------------------------------------------------- fit
    def fit(self, refine=True):
        from .results import STResult
        d = self._design(self.data)
        dy, Z, s, names = d["dy"], d["Z"], d["s"], d["names"]
        n, m = Z.shape
        idx_nl = self._nl_index(names)
        W = Z[:, idx_nl]
        m1 = len(idx_nl)
        s_mean, s_sd = float(s.mean()), float(s.std(ddof=0))
        if s_sd <= 0:
            raise ValueError("the transition variable is constant")
        zs = (s - s_mean) / s_sd
        kind = self.transition
        nloc = N_LOCATIONS[kind]
        K = m + m1 + 1 + nloc
        if n <= K + 2:
            raise ValueError("not enough observations (%d) for %d parameters" % (n, K))

        # 1. grid search
        grid = make_grid(zs, kind, self.n_gamma, self.n_c, self.gamma_max)
        scored = []
        for g, c in grid:
            G = transition_function(zs, g, c, kind)
            ssr, _ = _ols_ssr(dy, Z, W, G)
            scored.append((ssr, g, c))
        scored.sort(key=lambda t: t[0])
        lo, hi = float(zs.min()), float(zs.max())
        lg_lo, lg_hi = np.log(0.1), np.log(self.gamma_max)

        def objective(theta):
            if theta[0] < lg_lo or theta[0] > lg_hi:
                return 1e18
            g, c = decode(kind, theta)
            if np.any(c < lo) or np.any(c > hi):
                return 1e18
            G = transition_function(zs, g, c, kind)
            return _ols_ssr(dy, Z, W, G)[0]

        best_theta, best_val = encode(kind, scored[0][1], scored[0][2]), scored[0][0]
        if refine:
            for ssr0, g0, c0 in scored[:3]:
                th0 = encode(kind, g0, c0)
                r = optimize.minimize(objective, th0, method="Nelder-Mead",
                                      options=dict(xatol=1e-5, fatol=1e-10, maxiter=600))
                if r.fun < best_val:
                    best_val, best_theta = float(r.fun), r.x
        gamma_s, c_s = decode(kind, best_theta)
        G = transition_function(zs, gamma_s, c_s, kind)
        ssr, beta = _ols_ssr(dy, Z, W, G)

        # 2. non-linear least squares covariance
        nb = m + m1

        def fitted(par):
            b, g, c = par[:nb], par[nb], par[nb + 1:]
            Gp = transition_function(zs, g, c, kind)
            return Z @ b[:m] + Gp * (W @ b[m:])

        par = np.concatenate([beta, [gamma_s], c_s])
        J = numerical_jacobian(fitted, par)
        resid = dy - fitted(par)
        sigma2 = float(resid @ resid) / (n - K)
        JtJi = np.linalg.pinv(J.T @ J)
        if self.cov_type == "nonrobust":
            cov = sigma2 * JtJi
        else:
            scores = J * resid[:, None]
            if self.cov_type == "HC1":
                meat = scores.T @ scores * n / (n - K)
            else:
                L = self.hac_lags if self.hac_lags is not None else int(np.floor(4 * (n / 100.0) ** (2.0 / 9.0)))
                meat = newey_west_meat(scores, L) * n / (n - K)
            cov = JtJi @ meat @ JtJi
        return STResult(self, d, idx_nl, beta, cov, gamma_s, c_s, s_mean, s_sd, G, resid, sigma2)
