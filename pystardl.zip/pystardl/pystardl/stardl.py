"""Smooth Transition ARDL (STARDL)."""
from .base import STBase


class STARDL(STBase):
    """Smooth Transition Autoregressive Distributed Lag model.

    ECM representation::

        dy_t = c + rho y_{t-1} + theta' x_{t-1} + sum phi_i dy_{t-i} + sum pi_i' dx_{t-i}
               + G(s_t; gamma, c) * [ same terms with starred coefficients ] + e_t

    Parameters
    ----------
    data : DataFrame in time order (or give ``time_col``).
    depvar, indepvars : names of y and of the regressors (str or list).
    p, q : ARDL orders (int, or dict {var: q} for q).  The ECM has p-1 lags of
        dy and q lags of dx (dx_t, ..., dx_{t-q+1}).
    transition_var : 'time' (t/T), a column name, or 'D.<column>' (first
        difference).  ``delay`` lags it.
    transition : 'logistic', 'exponential' or 'logistic2'.
    nonlinear : 'all', 'lr', 'sr', a list of column names (see ``column_names``)
        or of variable names whose coefficients may change with G.
    """
    model_name = "STARDL"

    def __init__(self, data, depvar, indepvars, **kwargs):
        kwargs.pop("asym_vars", None)
        super(STARDL, self).__init__(data, depvar, indepvars, asym_vars=[], **kwargs)

    @property
    def column_names(self):
        return self._design(self.data)["names"]
