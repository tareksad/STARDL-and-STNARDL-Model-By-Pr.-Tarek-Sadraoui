"""Smooth Transition Nonlinear ARDL (STNARDL)."""
from .base import STBase


class STNARDL(STBase):
    """Smooth Transition NARDL: asymmetric (partial-sum) effects whose
    coefficients also change smoothly with a transition variable.

    Each variable in ``asym_vars`` (default: all regressors) is split into
    x^+ and x^- (cumulated positive/negative changes) as in Shin, Yu and
    Greenwood-Nimmo (2014); the remaining regressors enter symmetrically.
    All other arguments are those of :class:`pystardl.STARDL`.
    """
    model_name = "STNARDL"

    def __init__(self, data, depvar, indepvars, asym_vars=None, **kwargs):
        from .utils import as_list
        ind = as_list(indepvars)
        asym = ind if asym_vars is None else as_list(asym_vars)
        super(STNARDL, self).__init__(data, depvar, indepvars, asym_vars=asym, **kwargs)

    @property
    def column_names(self):
        return self._design(self.data)["names"]
