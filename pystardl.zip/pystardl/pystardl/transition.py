"""Smooth transition functions and their search grids."""
import itertools
import numpy as np
from scipy.special import expit

KINDS = ("logistic", "exponential", "logistic2")
N_LOCATIONS = {"logistic": 1, "exponential": 1, "logistic2": 2}


def transition_function(s, gamma, c, kind="logistic"):
    """Evaluate G(s; gamma, c) in [0, 1].

    logistic     G = 1 / (1 + exp(-gamma (s - c)))                (LSTR1)
    exponential  G = 1 - exp(-gamma (s - c)^2)                    (ESTR)
    logistic2    G = 1 / (1 + exp(-gamma (s - c1)(s - c2)))       (LSTR2)
    """
    s = np.asarray(s, dtype=float)
    c = np.atleast_1d(np.asarray(c, dtype=float))
    if kind == "logistic":
        return expit(gamma * (s - c[0]))
    if kind == "exponential":
        return 1.0 - np.exp(-gamma * (s - c[0]) ** 2)
    if kind == "logistic2":
        return expit(gamma * (s - c[0]) * (s - c[1]))
    raise ValueError("transition must be one of %s" % (KINDS,))


def encode(kind, gamma, c):
    """Natural parameters -> unconstrained optimisation vector."""
    c = np.atleast_1d(c)
    if kind == "logistic2":
        return np.array([np.log(gamma), c[0], np.log(max(c[1] - c[0], 1e-6))])
    return np.array([np.log(gamma), c[0]])


def decode(kind, theta):
    """Unconstrained vector -> (gamma, c-array)."""
    gamma = float(np.exp(theta[0]))
    if kind == "logistic2":
        return gamma, np.array([theta[1], theta[1] + np.exp(theta[2])])
    return gamma, np.array([theta[1]])


def make_grid(zs, kind, n_gamma=9, n_c=15, gamma_max=128.0):
    """Starting values (gamma, c) on a grid for a standardised variable."""
    gammas = np.geomspace(0.5, min(gamma_max, 128.0), n_gamma)
    cands = np.unique(np.quantile(zs, np.linspace(0.10, 0.90, n_c)))
    if kind == "logistic2":
        pairs = [(a, b) for a, b in itertools.combinations(cands, 2) if b - a > 0.2]
        if len(pairs) > 120:
            pairs = pairs[:: max(1, len(pairs) // 120)]
        locs = pairs
    else:
        locs = [(c,) for c in cands]
    return [(g, np.array(l)) for g in gammas for l in locs]
