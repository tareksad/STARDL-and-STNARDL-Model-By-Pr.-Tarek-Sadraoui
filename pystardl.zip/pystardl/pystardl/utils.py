"""Small helpers shared by the STARDL / STNARDL estimators."""
import numpy as np
import pandas as pd


def partial_sums(x):
    """Positive and negative partial sums of the changes of ``x``.

    x_t^+ = sum_{j<=t} max(dx_j, 0),   x_t^- = sum_{j<=t} min(dx_j, 0)
    (Shin, Yu and Greenwood-Nimmo, 2014).  The first observation is set to 0.
    """
    x = pd.Series(np.asarray(x, dtype=float), index=getattr(x, "index", None))
    dx = x.diff()
    pos = dx.clip(lower=0.0).fillna(0.0).cumsum()
    neg = dx.clip(upper=0.0).fillna(0.0).cumsum()
    return pos, neg


def as_list(x):
    if x is None:
        return []
    if isinstance(x, str):
        return [x]
    return list(x)


def stars(p):
    if p < 0.01:
        return "***"
    if p < 0.05:
        return "**"
    if p < 0.10:
        return "*"
    return ""


def numerical_jacobian(fun, x, rel_step=1e-6):
    """Central finite-difference Jacobian of a vector-valued function."""
    x = np.asarray(x, dtype=float)
    f0 = np.asarray(fun(x), dtype=float)
    J = np.empty((f0.size, x.size))
    for j in range(x.size):
        h = rel_step * max(1.0, abs(x[j]))
        xp, xm = x.copy(), x.copy()
        xp[j] += h
        xm[j] -= h
        J[:, j] = (np.asarray(fun(xp)) - np.asarray(fun(xm))) / (2 * h)
    return J


def newey_west_meat(scores, lags):
    """Newey-West long-run covariance of the rows of ``scores`` (n x K)."""
    S = scores.T @ scores
    for l in range(1, lags + 1):
        w = 1.0 - l / (lags + 1.0)
        G = scores[l:].T @ scores[:-l]
        S += w * (G + G.T)
    return S
