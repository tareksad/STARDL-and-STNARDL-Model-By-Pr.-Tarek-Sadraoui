"""Simulated data with a known STARDL / STNARDL data-generating process."""
import numpy as np
import pandas as pd
from scipy.special import expit


def simulate_stardl(n=300, seed=1, gamma=25.0, c=0.5, rho=-0.3, beta0=0.5, beta1=1.5,
                    pi=0.2, sigma=0.5):
    """DGP: dy = a + rho*y_{t-1} + (theta + G theta*) x_{t-1} + pi dx + e, with
    G = logistic(gamma (t/n - c)).  The long-run effect of x moves from
    ``beta0`` (G=0) to ``beta1`` (G=1)."""
    rng = np.random.RandomState(seed)
    x = np.cumsum(rng.randn(n))
    t = np.arange(1, n + 1) / float(n)
    G = expit(gamma * (t - c))
    theta0 = -rho * beta0
    theta1 = -rho * beta1
    y = np.zeros(n)
    for i in range(1, n):
        th = theta0 + G[i] * (theta1 - theta0)
        y[i] = y[i - 1] + 0.1 + rho * y[i - 1] + th * x[i - 1] + pi * (x[i] - x[i - 1]) + sigma * rng.randn()
    return pd.DataFrame({"y": y, "x": x}, index=pd.RangeIndex(n, name="t"))


def simulate_stnardl(n=400, seed=2, gamma=25.0, c=0.5, rho=-0.3, pos=(0.8, 1.6), neg=(0.4, 0.4),
                     sigma=0.5):
    """DGP with asymmetric long-run effects: x+ has long-run effect pos[0] -> pos[1]
    across regimes, x- has neg[0] -> neg[1]."""
    rng = np.random.RandomState(seed)
    dx = rng.randn(n)
    x = np.cumsum(dx)
    xp = np.cumsum(np.clip(dx, 0, None))
    xn = np.cumsum(np.clip(dx, None, 0))
    t = np.arange(1, n + 1) / float(n)
    G = expit(gamma * (t - c))
    y = np.zeros(n)
    for i in range(1, n):
        bp = pos[0] + G[i] * (pos[1] - pos[0])
        bn = neg[0] + G[i] * (neg[1] - neg[0])
        y[i] = y[i - 1] + 0.1 + rho * y[i - 1] - rho * (bp * xp[i - 1] + bn * xn[i - 1]) + sigma * rng.randn()
    return pd.DataFrame({"y": y, "x": x}, index=pd.RangeIndex(n, name="t"))
