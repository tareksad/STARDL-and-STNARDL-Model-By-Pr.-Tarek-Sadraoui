"""Specification, cointegration-bounds and diagnostic tests."""
import numpy as np
import pandas as pd
from scipy import stats
from tabulate import tabulate

from .utils import as_list


# --------------------------------------------------------------- linearity
def _rank(A):
    return int(np.linalg.matrix_rank(A))


def _ssr(y, X):
    b = np.linalg.lstsq(X, y, rcond=None)[0]
    r = y - X @ b
    return float(r @ r), _rank(X)


def _f_added(e, base, added):
    ssr_b, r_b = _ssr(e, base)
    full = np.hstack([base, added])
    ssr_f, r_f = _ssr(e, full)
    df1, df2 = r_f - r_b, len(e) - r_f
    if df1 <= 0 or df2 <= 0 or ssr_f <= 0:
        return np.nan, np.nan
    F = ((ssr_b - ssr_f) / df1) / (ssr_f / df2)
    return F, float(stats.f.sf(F, df1, df2))


class LinearityResult(object):
    def __init__(self, table):
        self.table = table
        ok = table.dropna(subset=["p_linear"])
        self.best = ok.sort_values("p_linear").iloc[0] if len(ok) else None
        self.best_key = ok["p_linear"].idxmin() if len(ok) else None

    @property
    def recommended_transition(self):
        if self.best is None:
            return None
        return self.best["suggested"]

    def __str__(self):
        t = self.table.reset_index()
        s = tabulate(t.values.tolist(), headers=list(t.columns), tablefmt="fancy_grid", floatfmt=".4f")
        if self.best_key is not None:
            s += "\nSelected transition variable: %s (delay %s) -> %s" % (
                self.best_key[0], self.best_key[1], self.recommended_transition)
        return s

    __repr__ = __str__


def linearity_test(data, depvar, indepvars, asym_vars=None, p=1, q=1, candidates=None,
                   delays=(1, 2, 3), nonlinear="all", constant=True, trend=False, time_col=None):
    """Teraesvirta (1994) LM-type linearity test against smooth transition.

    For each candidate transition variable s (and delay) the residuals of the
    linear ARDL/NARDL are regressed on Z, Z*s, Z*s^2, Z*s^3 (third-order Taylor
    expansion), where Z are the terms allowed to change.  H0: all Taylor
    coefficients are zero, which avoids the unidentified-nuisance-parameter
    problem.  The sequence H04, H03, H02 suggests logistic (LSTR1) versus
    exponential/second-order logistic (ESTR/LSTR2).
    """
    from .stardl import STARDL
    from .stnardl import STNARDL
    indepvars = as_list(indepvars)
    asym = as_list(asym_vars)
    cls = STNARDL if asym else STARDL
    kw = dict(p=p, q=q, nonlinear=nonlinear, constant=constant, trend=trend, time_col=time_col)
    if asym:
        kw["asym_vars"] = asym
    if candidates is None:
        candidates = ["time"] + ["D." + v for v in indepvars] + ["D." + depvar]
    rows = []
    for cand in as_list(candidates):
        for d in ([0] if cand == "time" else list(delays)):
            model = cls(data, depvar, indepvars, transition_var=cand, delay=d, **kw)
            des = model._design(model.data)
            Z, dy, s = des["Z"], des["dy"], des["s"]
            idx = model._nl_index(des["names"])
            W = Z[:, idx]
            zs = (s - s.mean()) / s.std()
            b = np.linalg.lstsq(Z, dy, rcond=None)[0]
            e = dy - Z @ b
            A1, A2, A3 = W * zs[:, None], W * (zs ** 2)[:, None], W * (zs ** 3)[:, None]
            F, pv = _f_added(e, Z, np.hstack([A1, A2, A3]))
            F4, p4 = _f_added(e, np.hstack([Z, A1, A2]), A3)
            F3, p3 = _f_added(e, np.hstack([Z, A1]), A2)
            F2, p2 = _f_added(e, Z, A1)
            # Teraesvirta's rule (smallest p-value of H04, H03, H02); the three
            # F-tests have the same degrees of freedom, so the largest F is used
            # to break ties when the p-values are numerically zero.
            if pv > 0.05:
                sugg = "linear (not rejected at 5%)"
            elif F3 > max(F4, F2):
                sugg = "exponential/logistic2"
            else:
                sugg = "logistic"
            rows.append(dict(transition_var=cand, delay=d, F=F, p_linear=pv,
                             p_H04=p4, p_H03=p3, p_H02=p2, suggested=sugg))
    table = pd.DataFrame(rows).set_index(["transition_var", "delay"])
    return LinearityResult(table)


# ------------------------------------------------------------------ bounds
def _bounds_stats(dy, Z, W, G, lr_lin, nl_lr, dep_i):
    X = np.hstack([Z, W * G[:, None]])
    XtXi = np.linalg.pinv(X.T @ X)
    b = XtXi @ X.T @ dy
    r = dy - X @ b
    s2 = float(r @ r) / (len(dy) - _rank(X))
    V = s2 * XtXi
    m = Z.shape[1]
    cols = list(lr_lin) + [m + j for j in nl_lr]
    R = np.zeros((len(cols), X.shape[1]))
    R[np.arange(len(cols)), cols] = 1
    Rb = R @ b
    F = float(Rb @ np.linalg.pinv(R @ V @ R.T) @ Rb) / len(cols)
    t = float(b[dep_i] / np.sqrt(V[dep_i, dep_i]))
    return F, t


class BoundsTestResult(object):
    def __init__(self, table, F, t, n_sim):
        self.table, self.F, self.t, self.n_sim = table, F, t, n_sim

    def __str__(self):
        head = "Bounds test (transition parameters held fixed; %d simulations per bound)\n" % self.n_sim
        head += "F-statistic = %.4f | t-statistic (rho) = %.4f\n" % (self.F, self.t)
        t = self.table.reset_index()
        return head + tabulate(t.values.tolist(), headers=list(t.columns),
                               tablefmt="fancy_grid", floatfmt=".4f")

    __repr__ = __str__


def bounds_test(res, n_sim=400, levels=(0.10, 0.05, 0.01), seed=0):
    """Pesaran-Shin-Smith style bounds test with simulated critical values.

    H0: every long-run coefficient (rho, theta and, if present, their G*
    counterparts) is zero.  Lower bound: regressors I(0); upper bound:
    regressors I(1).  Critical values are simulated for the *same* design,
    holding G_t at its estimated path, so they depend on the specification;
    treat them as conditional on (gamma, c).
    """
    model = res.model
    names = res.names_lin
    dep = "L." + res.depvar
    lr_lin = [i for i, nm in enumerate(names) if nm.startswith("L.")]
    nl_lr = [j for j, i in enumerate(res.idx_nl) if names[i].startswith("L.")]
    dep_i = names.index(dep)
    F0, t0 = _bounds_stats(res.dy, res.Z, res.W, res.G, lr_lin, nl_lr, dep_i)
    rng = np.random.RandomState(seed)
    base = model.data.copy()
    s_full = model._trans_series(base).values
    T = len(base)
    sims = {"I0": ([], []), "I1": ([], [])}
    for kind in ("I0", "I1"):
        for _ in range(n_sim):
            sim = base.copy()
            sim[model.depvar] = np.cumsum(rng.randn(T))
            for v in model.indepvars:
                z = rng.randn(T)
                sim[v] = np.cumsum(z) if kind == "I1" else z
            des = model._design(sim, s_override=s_full)
            if len(des["dy"]) != len(res.G):
                raise RuntimeError("simulated sample length mismatch")
            W = des["Z"][:, res.idx_nl]
            F, t = _bounds_stats(des["dy"], des["Z"], W, res.G, lr_lin, nl_lr, dep_i)
            sims[kind][0].append(F)
            sims[kind][1].append(t)
    rows = []
    for a in levels:
        f_lo = np.quantile(sims["I0"][0], 1 - a)
        f_hi = np.quantile(sims["I1"][0], 1 - a)
        t_lo = np.quantile(sims["I0"][1], a)
        t_hi = np.quantile(sims["I1"][1], a)
        dF = "reject H0 (cointegration)" if F0 > f_hi else ("fail to reject" if F0 < f_lo else "inconclusive")
        dt = "reject H0 (cointegration)" if t0 < t_hi else ("fail to reject" if t0 > t_lo else "inconclusive")
        rows.append(dict(level=a, F_I0=f_lo, F_I1=f_hi, F_decision=dF,
                         t_I0=t_lo, t_I1=t_hi, t_decision=dt))
    return BoundsTestResult(pd.DataFrame(rows).set_index("level"), F0, t0, n_sim)


# ------------------------------------------------------------- diagnostics
def diagnostics(res, lags=(1, 4)):
    """Residual diagnostics: serial correlation, heteroskedasticity, normality, RESET."""
    e, X, n = res.residuals, res.X, res.n
    rows = []
    denom = float(e @ e)
    for L in as_list(lags):
        lagmat = np.column_stack([np.concatenate([np.zeros(i), e[:-i]]) for i in range(1, L + 1)])
        ssr, _ = _ssr(e, np.hstack([X, lagmat]))
        lm = n * (1 - ssr / denom)
        rows.append(("Breusch-Godfrey LM (order %d)" % L, lm, float(stats.chi2.sf(lm, L)), L))
    u = e ** 2
    ssr, rk = _ssr(u, X)
    has_const = res.model.constant
    tss = float(((u - u.mean()) ** 2).sum()) if has_const else float(u @ u)
    r2 = 1 - ssr / tss
    df = max(rk - 1, 1) if has_const else rk
    rows.append(("Breusch-Pagan (Koenker) LM", n * r2, float(stats.chi2.sf(n * r2, df)), df))
    L = 4
    Y = u[L:]
    Xa = np.column_stack([np.ones(len(Y))] + [u[L - i: len(u) - i] for i in range(1, L + 1)])
    ssr, _ = _ssr(Y, Xa)
    r2 = 1 - ssr / float(((Y - Y.mean()) ** 2).sum())
    rows.append(("ARCH LM (order 4)", (n - L) * r2, float(stats.chi2.sf((n - L) * r2, L)), L))
    jb, pj = stats.jarque_bera(e)[:2]
    rows.append(("Jarque-Bera", float(jb), float(pj), 2))
    yh = res.fitted
    ssr_u, r_u = _ssr(res.dy, np.hstack([X, np.column_stack([yh ** 2, yh ** 3])]))
    ssr_r, r_r = _ssr(res.dy, X)
    df1, df2 = r_u - r_r, n - r_u
    if df1 > 0 and df2 > 0:
        F = ((ssr_r - ssr_u) / df1) / (ssr_u / df2)
        rows.append(("RESET (powers 2-3), F", float(F), float(stats.f.sf(F, df1, df2)), df1))
    dw = float(np.sum(np.diff(e) ** 2) / denom)
    rows.append(("Durbin-Watson", dw, np.nan, np.nan))
    return pd.DataFrame(rows, columns=["test", "statistic", "p_value", "df"]).set_index("test")


def cusum(res):
    """CUSUM and CUSUM-of-squares of recursive residuals (Brown, Durbin, Evans, 1975).

    The regression is linear in the coefficients given the estimated (gamma, c).
    CUSUM bounds use the 5% line a=0.948; CUSUMSQ bounds use the Kolmogorov
    approximation of Durbin (1969), so they are approximate.
    """
    X, y = res.X, res.dy
    n = len(y)
    k = _rank(X)
    w = []
    for r in range(k, n):
        Xr = X[:r]
        P = np.linalg.pinv(Xr.T @ Xr)
        b = P @ Xr.T @ y[:r]
        x = X[r]
        w.append((y[r] - x @ b) / np.sqrt(1.0 + x @ P @ x))
    w = np.array(w)
    sig = np.sqrt(np.sum((w - w.mean()) ** 2) / (n - k - 1))
    cs = np.cumsum(w) / sig
    r_idx = np.arange(1, len(w) + 1)
    sq = np.sqrt(n - k)
    bound = 0.948 * (sq + 2.0 * r_idx / sq)
    ss = np.cumsum(w ** 2) / np.sum(w ** 2)
    line = r_idx / float(len(w))
    c0 = 1.358 / np.sqrt((n - k) / 2.0 - 1.0)
    out = pd.DataFrame({"cusum": cs, "cusum_upper": bound, "cusum_lower": -bound,
                        "cusumsq": ss, "cusumsq_mean": line,
                        "cusumsq_upper": line + c0, "cusumsq_lower": line - c0},
                       index=res.index[k:])
    return out
