"""Information-criterion lag selection for (p, q)."""
import pandas as pd

from .stardl import STARDL
from .stnardl import STNARDL


def select_lags(data, depvar, indepvars, asym_vars=None, max_p=4, max_q=4, min_q=0,
                criterion="bic", model="STARDL", **kwargs):
    """Search p in 1..max_p and q in min_q..max_q on a common estimation sample.

    A coarse grid and no refinement are used for speed; re-estimate the chosen
    orders with ``fit()`` afterwards.  ``model`` is 'STARDL' or 'STNARDL'.
    """
    crit = criterion.lower()
    if crit not in ("aic", "bic", "hqic"):
        raise ValueError("criterion must be 'aic', 'bic' or 'hqic'")
    cls = STNARDL if model.upper() == "STNARDL" else STARDL
    Lmax = max(max_p, max_q, 1)
    rows = []
    for p in range(1, max_p + 1):
        for q in range(min_q, max_q + 1):
            drop = Lmax - max(p, q, 1)
            sub = data.iloc[drop:]
            kw = dict(kwargs, p=p, q=q, n_gamma=6, n_c=9)
            if cls is STNARDL:
                kw["asym_vars"] = asym_vars
            try:
                res = cls(sub, depvar, indepvars, **kw).fit(refine=False)
                rows.append(dict(p=p, q=q, n=res.n, aic=res.aic, bic=res.bic, hqic=res.hqic))
            except Exception as exc:  # noqa
                rows.append(dict(p=p, q=q, n=0, aic=float("nan"), bic=float("nan"), hqic=float("nan")))
    table = pd.DataFrame(rows).sort_values(crit).reset_index(drop=True)
    best = table.dropna(subset=[crit]).iloc[0]
    return int(best["p"]), int(best["q"]), table


def compare_transitions(data, depvar, indepvars, model="STARDL", asym_vars=None, **kwargs):
    """Fit the logistic, exponential and second-order logistic transitions and
    rank them by information criteria (the linearity-test sequence is only a
    heuristic, so comparing fits is a useful complement)."""
    cls = STNARDL if model.upper() == "STNARDL" else STARDL
    rows, fits = [], {}
    for kind in ("logistic", "exponential", "logistic2"):
        kw = dict(kwargs, transition=kind)
        if cls is STNARDL:
            kw["asym_vars"] = asym_vars
        res = cls(data, depvar, indepvars, **kw).fit()
        fits[kind] = res
        rows.append(dict(transition=kind, ssr=res.ssr, aic=res.aic, bic=res.bic, hqic=res.hqic,
                         gamma=res.gamma, c=",".join("%.4g" % v for v in res.c)))
    return pd.DataFrame(rows).set_index("transition").sort_values("bic"), fits
